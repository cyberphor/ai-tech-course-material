import sourcedefender
from submitter_utils.submitter import Submitter
from submitter_utils.tasks import TASKS


def submit(task_number, refresh_credentials):
    if task_number in TASKS:
        submitter = Submitter(task_number, TASKS, refresh_credentials)
        submitter.run()
    else:
        valid_tasks = ', '.join(str(t) for t in TASKS.keys())
        print(f'\n"{task_number}" is not a valid task number.\n'
                f'Please, choose one from the following: {valid_tasks}')
